-- Table for Stations
CREATE TABLE Stations (
    StationID INT PRIMARY KEY,
    StationName VARCHAR(255) NOT NULL,
    Location VARCHAR(255) NOT NULL
);

-- Table for Trains
CREATE TABLE Trains (
    TrainID INT PRIMARY KEY,
    TrainName VARCHAR(255) NOT NULL,
    TrainType VARCHAR(100) NOT NULL, -- E.g., Express, Local
    Capacity INT NOT NULL
);

-- Table for Train Schedules
CREATE TABLE TrainSchedules (
    ScheduleID INT PRIMARY KEY,
    TrainID INT,
    DepartureStationID INT,
    ArrivalStationID INT,
    DepartureTime DATETIME,
    ArrivalTime DATETIME,
    FOREIGN KEY (TrainID) REFERENCES Trains(TrainID),
    FOREIGN KEY (DepartureStationID) REFERENCES Stations(StationID),
    FOREIGN KEY (ArrivalStationID) REFERENCES Stations(StationID)
);

-- Table for Passengers
CREATE TABLE Passengers (
    PassengerID INT PRIMARY KEY,
    FirstName VARCHAR(100),
    LastName VARCHAR(100),
    Age INT,
    Gender VARCHAR(10),
    Email VARCHAR(100),
    PhoneNumber VARCHAR(20)
);

-- Table for Bookings 
CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY,
    PassengerID INT,
    ScheduleID INT,
    SeatNumber INT,
    BookingDate DATETIME,
    FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID),
    FOREIGN KEY (ScheduleID) REFERENCES TrainSchedules(ScheduleID)
);

-- Insert data into Stations
INSERT INTO Stations (StationID, StationName, Location) 
VALUES 
(1, 'Islamabad', 'Islamabad'), 
(2, 'Rawalpindi', 'Rawalpindi'), 
(3, 'Lahore', 'Lahore'), 
(4, 'Karachi', 'Karachi'), 
(5, 'Peshawar', 'Peshawar');
 select * from Stations;

 -- Insert data into Trains
INSERT INTO Trains (TrainID, TrainName, TrainType, Capacity) 
VALUES 
(1, 'Green Line Express', 'Express', 200), 
(2, 'Peshawar Shuttle', 'Local', 150), 
(3, 'Karachi Fast', 'Express', 300), 
(4, 'Lahore Local', 'Local', 120), 
(5, 'Super Fast', 'Express', 250);
 select * from Trains;

 -- Insert data into TrainSchedules
INSERT INTO TrainSchedules (ScheduleID, TrainID, DepartureStationID, ArrivalStationID, DepartureTime, ArrivalTime) 
VALUES 
(1, 1, 1, 2, '2025-01-26 08:00:00', '2025-01-26 10:00:00'),
(2, 2, 2, 3, '2025-01-26 09:00:00', '2025-01-26 11:30:00'),
(3, 3, 3, 4, '2025-01-26 10:30:00', '2025-01-26 14:00:00'),
(4, 4, 4, 5, '2025-01-26 11:00:00', '2025-01-26 14:30:00'),
(5, 5, 1, 3, '2025-01-26 12:00:00', '2025-01-26 16:00:00');
 select * from TrainSchedules;

 -- Insert data into Passengers
INSERT INTO Passengers (PassengerID, FirstName, LastName, Age, Gender, Email, PhoneNumber) 
VALUES 
(1, 'Ali', 'Khan', 25, 'Male', 'ali.khan@example.com', '1234567890'),
(2, 'Sara', 'Ahmed', 30, 'Female', 'sara.ahmed@example.com', '9876543210'),
(3, 'Ahmed', 'Zahid', 28, 'Male', 'ahmed.zahid@example.com', '1230987654'),
(4, 'Fatima', 'Ali', 22, 'Female', 'fatima.ali@example.com', '5678123456'),
(5, 'Bilal', 'Shah', 35, 'Male', 'bilal.shah@example.com', '6543217890');

select * from Passengers;

-- Insert data into Bookings
INSERT INTO Bookings (BookingID, PassengerID, ScheduleID, SeatNumber, BookingDate) 
VALUES 
(1, 1, 1, 12, '2025-01-25 16:00:00'),
(2, 2, 2, 5, '2025-01-25 17:00:00'),
(3, 3, 3, 8, '2025-01-25 18:00:00'),
(4, 4, 4, 2, '2025-01-25 19:00:00'),
(5, 5, 5, 15, '2025-01-25 20:00:00');

select * from Bookings;


CREATE TABLE TrainTypes (
    TrainTypeID INT PRIMARY KEY,
    TypeName VARCHAR(100),
    Description VARCHAR(255)
);

INSERT INTO TrainTypes (TrainTypeID, TypeName, Description)
VALUES 
(1, 'Express', 'High-speed train for long distances'),
(2, 'Local', 'Train stopping at all stations along the route'),
(3, 'Cargo', 'Train for transporting goods');
SELECT * FROM TrainTypes;


CREATE TABLE PaymentMethods (
    PaymentMethodID INT PRIMARY KEY,
    MethodName VARCHAR(50),
    Description VARCHAR(255)
);

INSERT INTO PaymentMethods (PaymentMethodID, MethodName, Description)
VALUES 
(1, 'Credit Card', 'Payment made using a credit card'),
(2, 'Debit Card', 'Payment made using a debit card'),
(3, 'Cash', 'Payment made in cash');
SELECT * FROM PaymentMethods;


CREATE TABLE FeedbackCategories (
    FeedbackCategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(100),
    Description VARCHAR(255)
);

INSERT INTO FeedbackCategories (FeedbackCategoryID, CategoryName, Description)
VALUES 
(1, 'Service', 'Feedback about train service quality'),
(2, 'Cleanliness', 'Feedback about cleanliness of trains and stations'),
(3, 'Punctuality', 'Feedback about train arrival and departure timings');
SELECT * FROM FeedbackCategories;


CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    Name VARCHAR(100),
    Position VARCHAR(50),
    Phone VARCHAR(20),
    Email VARCHAR(100)
);

INSERT INTO Employees (EmployeeID, Name, Position, Phone, Email)
VALUES 
(1, 'Ali Khan', 'Driver', '03001234567', 'ali.khan@example.com'),
(2, 'Ayesha Ahmed', 'Conductor', '03007654321', 'ayesha.ahmed@example.com'),
(3, 'Imran Malik', 'Admin', '03009876543', 'imran.malik@example.com');
SELECT * FROM Employees;



CREATE TABLE Classes (
    ClassID INT PRIMARY KEY,
    ClassName VARCHAR(50),
    Description VARCHAR(255)
);

INSERT INTO Classes (ClassID, ClassName, Description)
VALUES 
(1, 'Economy', 'Affordable class with basic facilities'),
(2, 'Business', 'Luxury class with premium services'),
(3, 'First Class', 'High-end class with exclusive amenities');
SELECT * FROM Classes;



CREATE TABLE Discounts (
    DiscountID INT PRIMARY KEY,
    DiscountName VARCHAR(100),
    DiscountPercent DECIMAL(5, 2),
    EligibilityCriteria VARCHAR(255)
);

INSERT INTO Discounts (DiscountID, DiscountName, DiscountPercent, EligibilityCriteria)
VALUES 
(1, 'Student Discount', 20.00, 'Valid student ID required'),
(2, 'Senior Citizen Discount', 30.00, 'Age 60 or above'),
(3, 'Family Package', 15.00, 'Minimum 4 tickets booked together');
SELECT * FROM Discounts;



CREATE TABLE TrainDelays (
    DelayID INT PRIMARY KEY,
    DelayDuration INT,
    Reason VARCHAR(255)
);
INSERT INTO TrainDelays (DelayID, DelayDuration, Reason)
VALUES 
(1, 30, 'Technical fault'),
(2, 15, 'Weather conditions'),
(3, 45, 'Track maintenance');

SELECT * FROM TrainDelays;


CREATE TABLE Complaints (
    ComplaintID INT PRIMARY KEY,
    PassengerID INT,
    TrainID INT,
    Description VARCHAR(255),
    Status VARCHAR(50),
    Date DATETIME,
    FOREIGN KEY (PassengerID) REFERENCES Passengers(PassengerID),
    FOREIGN KEY (TrainID) REFERENCES Trains(TrainID)
);

INSERT INTO Complaints (ComplaintID, PassengerID, TrainID, Description, Status, Date)
VALUES 
(1, 1, 1, 'Seat was broken', 'Resolved', '2025-01-26 10:00:00'),
(2, 2, 2, 'Train was late', 'Pending', '2025-01-26 12:00:00'),
(3, 3, 3, 'Unclean compartments', 'Resolved', '2025-01-26 14:00:00');
SELECT * FROM Complaints;

-- Update Passenger 1
UPDATE Passengers
SET FirstName = 'Younas', 
    LastName = 'Ahmad', 
    Gender = 'Male', 
    Email = 'younas.ahmad@example.com'
WHERE PassengerID = 1;

-- Update Passenger 2
UPDATE Passengers
SET FirstName = 'Muhammad', 
    LastName = 'Faizan', 
    Gender = 'Male', 
    Email = 'muhammad.faizan@example.com'
WHERE PassengerID = 2;

-- Update Passenger 3
UPDATE Passengers
SET FirstName = 'Khurram', 
    LastName = 'Iftikhar', 
    Gender = 'Male', 
    Email = 'khurram.iftikhar@example.com'
WHERE PassengerID = 3;

-- Update Passenger 4
UPDATE Passengers
SET FirstName = 'Ali', 
    LastName = 'Raza', 
    Gender = 'Male', 
    Email = 'ali.raza@example.com'
WHERE PassengerID = 4;

-- Update Passenger 5
UPDATE Passengers
SET FirstName = 'Muhammad', 
    LastName = 'Bilal', 
    Gender = 'Male', 
    Email = 'muhammad.bilal@example.com'
WHERE PassengerID = 5;

SELECT * FROM Passengers;


